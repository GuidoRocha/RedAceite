﻿using DAO.Repositorio;
using DAO.Singleton;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using DAO.UnitofWork;

namespace BLL.Factory
{
    public class EmpleadoBLLFactory:IEmpleadoBLLFactory
    {
        public EmpleadoBLL CrearEmpleadoBLL()
        {
            // Crear una instancia del UnitOfWork usando la conexión singleton
            IUnitOfWork unitOfWork = new UnitOfWork(DatabaseConnectionSingleton.Instance.ConnectionString);
            return new EmpleadoBLL(unitOfWork);
        }

    }
}
