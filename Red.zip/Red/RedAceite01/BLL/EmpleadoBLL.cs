﻿using DAO.Repositorio;
using DAO.UnitofWork;
using Dominio;
using System;
using System.Collections.Generic;
using System.Diagnostics.Contracts;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL
{
    public class EmpleadoBLL
    {
        private readonly IUnitOfWork _unitOfWork;

        public EmpleadoBLL(IUnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }

        public bool VerificarCredenciales(string nombreUsuario, string contraseña)
        {
            var empleado = _unitOfWork.EmpleadoRepository.ObtenerPorCredenciales(nombreUsuario, contraseña);
            return empleado != null;
        }

        public Empleado ObtenerDetallesEmpleado(string nombreUsuario, string contraseña)
        {
            // Utiliza el método ObtenerPorCredenciales del repositorio a través del UnitOfWork
            return _unitOfWork.EmpleadoRepository.ObtenerPorCredenciales(nombreUsuario, contraseña);
        }

        public void AltaEmpleado(Guid id,string nombre, string apellido, string email, string nombreUsuario, string contraseña, string telefono, string direccion, string ciudad, int idRol)
        {
            try
            {
                var nuevoEmpleado = new Empleado
                {
                    Nombre = nombre,
                    Apellido = apellido,
                    Email = email,
                    IdEmpleadoGuid = id


                };
                /*
                var nuevoUsuario = new Usuario
                {
                    NombreUsuario = nombreUsuario,
                    Contraseña = contraseña
                };

                var nuevoContacto = new Contacto
                {
                    Telefono = telefono,
                    Direccion = direccion,
                    Ciudad = ciudad
                };
                */

                _unitOfWork.EmpleadoRepository.InsertarEmpleado(nuevoEmpleado);

                /*   nuevoUsuario.IdEmpleado = nuevoEmpleado.IdEmpleado;
                   _unitOfWork.Usuarios.InsertarUsuario(nuevoUsuario);

                   nuevoContacto.IdEmpleado = nuevoEmpleado.IdEmpleado;
                   _unitOfWork.Contactos.InsertarContacto(nuevoContacto);

                   _unitOfWork.EmpleadoRoles.InsertarEmpleadoRol(nuevoEmpleado.IdEmpleado, idRol);
                 */
                //_unitOfWork.Commit(); // Confirmar la transacción si todo fue bien
            
            }
            catch
            {
                _unitOfWork.Rollback(); // Deshacer la transacción en caso de error
                throw;
            }
        }

    }
}
