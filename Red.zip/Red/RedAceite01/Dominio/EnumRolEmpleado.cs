﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dominio
{
    public class Rol
    {
        public int IdRol { get; set; } // ID único del rol
        public string NombreRol { get; set; } // Nombre del rol (Admin, User, etc.)
        
    }
}
