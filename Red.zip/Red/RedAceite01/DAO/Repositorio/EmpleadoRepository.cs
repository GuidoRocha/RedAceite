﻿using Dominio;
using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAO.Repositorio
{
    public class EmpleadoRepository : IEmpleadoRepository
    {
        private readonly SqlConnection _connection;
        private readonly SqlTransaction _transaction;
        public EmpleadoRepository(SqlConnection connection, SqlTransaction transaction)
        {
            _connection = connection;
            _transaction = transaction;
        }

        public Empleado ObtenerPorCredenciales(string nombreUsuario, string contraseña)
        {
            Empleado empleado = null;

            using (SqlCommand command = new SqlCommand())
            {
                command.Connection = _connection;
                command.Transaction = _transaction;
                command.CommandText = @"SELECT u.*, r.idRol
                                        FROM Usuario u
                                        JOIN Empleado e ON u.idEmpleado = e.idEmpleado
                                        JOIN EmpleadoRol r ON e.idEmpleado = r.idEmpleado
                                        WHERE u.nombreUsuario = @nombreUsuario AND u.contraseña = @contraseña;";
                command.Parameters.AddWithValue("@nombreUsuario", nombreUsuario);
                command.Parameters.AddWithValue("@contraseña", contraseña);

                using (SqlDataReader reader = command.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        empleado = new Empleado
                        {
                            IdEmpleado = (int)reader["idEmpleado"],
                            //IdEmpleadoGuid = (Guid)reader["IdEmpleadoGuid"],
                            IdRol = (int)reader["idRol"],
                            NombreUsuario = reader["nombreUsuario"].ToString(),
                            Contraseña = reader["contraseña"].ToString(),
                            FechaCreacion = (DateTime)reader["fechaCreacion"]
                        };
                    }
                }
            }
            return empleado;
        }

        public void InsertarEmpleado(Empleado empleado)
        {
            using (SqlCommand command = new SqlCommand())
            {
                command.Connection = _connection;  // Usar la conexión pasada
                command.Transaction = _transaction;
                command.CommandText = "INSERT INTO Empleado (idEmpleadoGuid, nombre, apellido, email) VALUES (@IdEmpleadoGuid, @nombre, @apellido, @email)";
                command.Parameters.AddWithValue("@idEmpleadoGuid", empleado.IdEmpleadoGuid);
                command.Parameters.AddWithValue("@nombre", empleado.Nombre);
                command.Parameters.AddWithValue("@apellido", empleado.Apellido);
                command.Parameters.AddWithValue("@email", empleado.Email);
                command.ExecuteNonQuery();
                command.Connection.Close();
            }

        }
    }
}
