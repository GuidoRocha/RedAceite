﻿using Dominio;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAO.Repositorio
{
    public interface IEmpleadoRepository
    {
        Empleado ObtenerPorCredenciales(string nombreUsuario, string contraseña);

        void InsertarEmpleado(Empleado empleado);
    }
}
