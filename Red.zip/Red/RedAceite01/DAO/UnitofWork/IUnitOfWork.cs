﻿using DAO.Repositorio;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAO.UnitofWork
{
    public interface IUnitOfWork : IDisposable
    {
        IEmpleadoRepository EmpleadoRepository { get; }
        void Commit(); // confirmar la transaccion
        void Rollback(); // deshacer la transaccion 
    }
}
