select * from Contacto

delete from Empleado

INSERT INTO Empleado (idEmpleado, nombre, apellido, email)
VALUES 
(1, 'Juan', 'Perez', 'juan.perez@example.com'),
(2, 'Maria', 'Gomez','maria.gomez@example.com'),
(3, 'Carlos', 'Lopez', 'carlos.lopez@example.com'),
(4, 'Ana', 'Martinez', 'ana.martinez@example.com'),
(5, 'Luis', 'Fernandez', 'luis.fernandez@example.com');

INSERT INTO Usuario (nombreUsuario, contrase�a, fechaCreacion, idEmpleado)
VALUES 
('JuanPerez', '1234', SYSDATETIME(), 1),
('MariaGomez', '1232', SYSDATETIME(), 2),
('CarlosLopez', '1234', SYSDATETIME(), 3),
('AnaMartinez', 'abcd', SYSDATETIME(), 4),
('LuisFernandez', '5678', SYSDATETIME(), 5);

INSERT INTO EmpleadoRol (idEmpleado, idRol)
VALUES 
(1, 1), -- Juan Perez como Admin
(2, 2), -- Maria Gomez como User
(3, 2), -- Carlos Lopez como User
(4, 1), -- Ana Martinez como Admin
(5, 2); -- Luis Fernandez como User

INSERT INTO Contacto (telefono, direccion, ciudad, idEmpleado)
VALUES 
('12345', 'Calle 123', 'Ciudad A', 1),
('98760', 'Avenida 456', 'Ciudad B', 2),
('55555', 'Plaza 789', 'Ciudad C', 3),
('2223', 'Boulevard 101', 'Ciudad D', 4),
('7778', 'Carrera 202', 'Ciudad E', 5);
--2. Obtener Informaci�n Completa de los Empleados y sus Roles
SELECT E.nombre, E.apellido, R.nombreRol
FROM Empleado E
JOIN EmpleadoRol ER ON E.idEmpleado = ER.idEmpleado
JOIN RolesEmpleado R ON ER.idRol = R.idRol;

--3. Obtener el Detalle de Contacto de un Empleado Espec�fico
SELECT E.nombre, E.apellido, C.telefono, C.direccion, C.ciudad
FROM Empleado E
JOIN Contacto C ON E.idEmpleado = C.idEmpleado
WHERE E.idEmpleado = 1;

--4. Listar Todos los Usuarios y sus Fechas de Creaci�n
SELECT nombreUsuario, fechaCreacion
FROM Usuario;

--5. Contar la Cantidad de Empleados por Rol
SELECT R.nombreRol, COUNT(*) AS cantidadEmpleados
FROM EmpleadoRol ER
JOIN RolesEmpleado R ON ER.idRol = R.idRol
GROUP BY R.nombreRol;

--6. Buscar Empleados por Nombre o Apellido
SELECT * 
FROM Empleado 
WHERE nombre LIKE '%Maria%' OR apellido LIKE '%Maria%';

--7. Verificar Usuarios Duplicados
SELECT nombreUsuario, COUNT(*) AS cantidad
FROM Usuario
GROUP BY nombreUsuario
HAVING COUNT(*) > 1;

--8. Obtener el �ltimo Empleado A�adido
SELECT TOP 1 *
FROM Empleado
ORDER BY idEmpleado DESC;

--9. Consultar Empleados que No Tienen Asignado un Rol
SELECT E.nombre, E.apellido
FROM Empleado E
LEFT JOIN EmpleadoRol ER ON E.idEmpleado = ER.idEmpleado
WHERE ER.idRol IS NULL;

--10. Eliminar un Empleado por idEmpleado
DELETE FROM Empleado WHERE idEmpleado = 5;




--Importantes





--1. Alta de Empleados (Insertar Nuevo Empleado)
-- Insertar un nuevo empleado
INSERT INTO Empleado (idEmpleado, nombre, apellido, email)
VALUES (6, 'Laura', 'Rodriguez', 'laura.rodriguez@example.com');

-- Insertar un nuevo usuario asociado al empleado
INSERT INTO Usuario (nombreUsuario, contrase�a, fechaCreacion, idEmpleado)
VALUES ('LauraRodriguez', 'abcd1234', GETDATE(), 6);

-- Insertar informaci�n de contacto para el nuevo empleado
INSERT INTO Contacto (telefono, direccion, ciudad, idEmpleado)
VALUES ('444-555-6666', 'Calle Nueva 101', 'Ciudad F', 6);

-- Asignar un rol al empleado
INSERT INTO EmpleadoRol (idEmpleado, idRol)
VALUES (6, 2); -- Asignar el rol de 'User' (por ejemplo, idRol = 2)

--------------------------------------------------------------------------------------------------------
--2. Baja de Empleados (Eliminar Empleado por idEmpleado)
-- Eliminar el contacto del empleado
DELETE FROM Contacto WHERE idEmpleado = 6;

-- Eliminar la relaci�n de roles del empleado
DELETE FROM EmpleadoRol WHERE idEmpleado = 6;

-- Eliminar el usuario asociado al empleado
DELETE FROM Usuario WHERE idEmpleado = 6;

-- Finalmente, eliminar el empleado
DELETE FROM Empleado WHERE idEmpleado = 6;
----------------------------------------------------------------------------------------------------------------------------

--3. Baja de Empleados (Eliminar Empleado por Nombre y Apellido)
-- Eliminar el contacto del empleado
DELETE FROM Contacto WHERE idEmpleado = (SELECT idEmpleado FROM Empleado WHERE nombre = 'Laura' AND apellido = 'Rodriguez');

-- Eliminar la relaci�n de roles del empleado
DELETE FROM EmpleadoRol WHERE idEmpleado = (SELECT idEmpleado FROM Empleado WHERE nombre = 'Laura' AND apellido = 'Rodriguez');

-- Eliminar el usuario asociado al empleado
DELETE FROM Usuario WHERE idEmpleado = (SELECT idEmpleado FROM Empleado WHERE nombre = 'Laura' AND apellido = 'Rodriguez');

-- Finalmente, eliminar el empleado
DELETE FROM Empleado WHERE nombre = 'Laura' AND apellido = 'Rodriguez';
-----------------------------------------------------------------------------------------------------------------------------------------------

--4. Modificaci�n de Empleados (Actualizar Datos por idEmpleado)
-- Actualizar el nombre, apellido y correo electr�nico del empleado con idEmpleado = 6
UPDATE Empleado
SET nombre = 'Laura', apellido = 'Rodriguez', email = 'laura.rod@example.com'
WHERE idEmpleado = 6;

-- Actualizar el nombre de usuario del empleado en la tabla Usuario
UPDATE Usuario
SET nombreUsuario = 'LauraRod'
WHERE idEmpleado = 6;

-- Actualizar la informaci�n de contacto del empleado
UPDATE Contacto
SET telefono = '9999', direccion = 'Calle Renovada 202', ciudad = 'Ciudad G'
WHERE idEmpleado = 6;
-----------------------------------------------------------------------------------------------------------------------------------------

--5. Modificaci�n de Empleados (Actualizar Datos por Nombre y Apellido)
-- Actualizar el nombre, apellido y correo electr�nico del empleado llamado Laura Rodriguez
UPDATE Empleado
SET nombre = 'Laura', apellido = 'Rodriguez', email = 'laura.rod@example.com'
WHERE nombre = 'Laura' AND apellido = 'Rodriguez';

-- Actualizar el nombre de usuario del empleado en la tabla Usuario
UPDATE Usuario
SET nombreUsuario = 'LauraRod'
WHERE idEmpleado = (SELECT idEmpleado FROM Empleado WHERE nombre = 'Laura' AND apellido = 'Rodriguez');

-- Actualizar la informaci�n de contacto del empleado
UPDATE Contacto
SET telefono = '7777', direccion = 'Calle Renovada 202', ciudad = 'Ciudad G'
WHERE idEmpleado = (SELECT idEmpleado FROM Empleado WHERE nombre = 'Laura' AND apellido = 'Rodriguez');
--------------------------------------------------------------------------------------------------------------------------------------------

--6. Verificaci�n de Existencia de un Empleado
-- Verificar existencia de un empleado por idEmpleado
SELECT COUNT(*) AS existe 
FROM Empleado 
WHERE idEmpleado = 6;

-- Verificar existencia de un empleado por nombre y apellido
SELECT COUNT(*) AS existe 
FROM Empleado 
WHERE nombre = 'Laura' AND apellido = 'Rodriguez';
