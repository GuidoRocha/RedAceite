﻿using BLL;
using BLL.Factory;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using RedAceite01;

namespace RedAceite01
{
    public partial class LoginForm : Form
    {
        public LoginForm()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void BtnLogIn_Click(object sender, EventArgs e)
        {
            string nombreUsuario = txtNombreUsuario.Text;
            string contraseña = TxtContraseña.Text;

            IEmpleadoBLLFactory factory = new EmpleadoBLLFactory();
            EmpleadoBLL empleadoBLL = factory.CrearEmpleadoBLL();

            var empleado = empleadoBLL.ObtenerDetallesEmpleado(nombreUsuario, contraseña);

            if (empleado != null)
            {
                // Ocultar el formulario de login
                this.Hide();
                // Pasa el objeto empleado al formulario de vista de empleados
                var vistaEmpleados = new VistaEmpeleados(empleado); // Pasa el empleado logueado
                vistaEmpleados.Show();

                
            }
            else
            {
                MessageBox.Show("Nombre de usuario o contraseña incorrectos");
            }
        }
    }
}
