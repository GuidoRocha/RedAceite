﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Services.Logic
{
    internal static class LoggerLogic
    {
        // Método para escribir logs con o sin excepción
        public static void WriteLog(Log log, Exception ex = null)
        {
            // Si el log es de error, puedes hacer algo adicional, como enviar notificaciones, alertas, etc.
            if (log.TraceLevel == System.Diagnostics.TraceLevel.Error)
            {
                // Por ejemplo, enviar una notificación (lógica futura)
            }

            // Llamamos a LoggerDao para escribir el log en el archivo
            LoggerDao.WriteLog(log, ex);
        }
    }
}
