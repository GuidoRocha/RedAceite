﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Services.Domain
{
    public class Usuario
    {
        public Guid IdUsuario { get; set; }
        public string NombreUsuario { get; set; }
        public string Password { get; set; }
        public List<Acceso> Accesos { get; set; } = new List<Acceso>();

        public Usuario(string nombreUsuario, string password)
        {
            IdUsuario = Guid.NewGuid();
            NombreUsuario = nombreUsuario;
            Password = password;
        }

        // Método para obtener todas las patentes de un usuario (recursivamente si hay familias)
        public List<Patente> GetPatentes()
        {
            List<Patente> patentes = new List<Patente>();
            ObtenerPatentesRecursivo(Accesos, patentes);
            return patentes;
        }

        private void ObtenerPatentesRecursivo(List<Acceso> accesos, List<Patente> patentes)
        {
            foreach (var acceso in accesos)
            {
                if (acceso.GetCount() == 0) // Si es una patente
                {
                    if (!patentes.Any(p => p.Id == acceso.Id))
                    {
                        patentes.Add(acceso as Patente);
                    }
                }
                else // Si es una familia
                {
                    var familia = acceso as Familia;
                    ObtenerPatentesRecursivo(familia.GetAccesos(), patentes);
                }
            }
        }

        // Método para obtener todas las familias a las que pertenece el usuario
        public List<Familia> GetFamilias()
        {
            List<Familia> familias = new List<Familia>();
            ObtenerFamiliasRecursivo(Accesos, familias);
            return familias;
        }

        private void ObtenerFamiliasRecursivo(List<Acceso> accesos, List<Familia> familias)
        {
            foreach (var acceso in accesos)
            {
                if (acceso.GetCount() > 0) // Si es una familia
                {
                    var familia = acceso as Familia;
                    if (!familias.Any(f => f.Id == familia.Id))
                    {
                        familias.Add(familia);
                    }
                    ObtenerFamiliasRecursivo(familia.GetAccesos(), familias);
                }
            }
        }
    }
}
