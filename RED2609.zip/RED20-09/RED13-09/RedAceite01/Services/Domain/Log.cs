﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dominio
{
    public class Log
    {
        public DateTime Date { get; set; } = DateTime.Now;  // Fecha del log
        public TraceLevel TraceLevel { get; set; }          // Nivel de severidad (Error, Info, etc.)
        public string Message { get; set; }                 // Mensaje a registrar
        public string UserId { get; set; }                  // ID del usuario (puede ser null si no es relevante)
    }
}
