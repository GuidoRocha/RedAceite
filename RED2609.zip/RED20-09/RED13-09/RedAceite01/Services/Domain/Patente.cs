﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Services.Domain
{
    public class Patente : Acceso
    {
        public string Codigo { get; set; }

        public Patente(string nombre, string codigo)
        {
            this.Nombre = nombre;
            this.Codigo = codigo;
        }

        public override void Add(Acceso component)
        {
            throw new InvalidOperationException("No se pueden añadir elementos a una Patente.");
        }

        public override void Remove(Acceso component)
        {
            throw new InvalidOperationException("No se pueden remover elementos de una Patente.");
        }

        public override int GetCount()
        {
            return 0; // Las patentes no tienen hijos
        }
    }
}
