﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Services.Domain
{
    public abstract class Acceso
    {
        public Guid Id { get; set; }
        public string Nombre { get; set; }

        public Acceso()
        {
            Id = Guid.NewGuid(); // Generar ID único
        }

        public abstract void Add(Acceso component);   // Añadir un componente
        public abstract void Remove(Acceso component); // Remover un componente
        public abstract int GetCount();               // Contar elementos dentro de este acceso
    }
}
