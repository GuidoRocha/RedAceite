﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Services.Domain
{
    public class Familia : Acceso
    {
        private List<Acceso> accesos = new List<Acceso>();

        public Familia(string nombre)
        {
            this.Nombre = nombre;
        }

        public override void Add(Acceso component)
        {
            accesos.Add(component);
        }

        public override void Remove(Acceso component)
        {
            accesos.Remove(component);
        }

        public override int GetCount()
        {
            return accesos.Count;
        }

        public List<Acceso> GetAccesos()
        {
            return accesos;
        }
    }
}
