﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Ser

namespace Dominio
{
    public class Empleado
    {
        public class Empleado
        {
            public Guid EmpleadoGuid { get; set; } // ID único del empleado
            public int IdEmpleado { get; set; }
            public string Nombre { get; set; }
            public string Apellido { get; set; }
            public string Email { get; set; }
            public string NombreUsuario { get; set; }
            public string Contraseña { get; set; }

            // Propiedad para representar el nombre del rol (si todavía lo necesitas)
            public string NombreRol { get; set; }

            // Nueva propiedad: Lista de accesos (patentes y familias)
            public List<Acceso> Accesos { get; set; } = new List<Acceso>();

            // Constructor vacío
            public Empleado() { }

            // Constructor que inicializa con accesos
            public Empleado(Guid id, string nombre, string apellido, string email, string nombreUsuario, string contraseña, List<Acceso> accesos)
            {
                EmpleadoGuid = id;
                Nombre = nombre;
                Apellido = apellido;
                Email = email;
                NombreUsuario = nombreUsuario;
                Contraseña = contraseña;
                Accesos = accesos ?? new List<Acceso>(); // Evitar null
            }

            // Método para obtener todas las patentes del empleado
            public List<Patente> GetPatentes()
            {
                List<Patente> patentes = new List<Patente>();
                ObtenerPatentesRecursivo(Accesos, patentes);
                return patentes;
            }

            private void ObtenerPatentesRecursivo(List<Acceso> accesos, List<Patente> patentes)
            {
                foreach (var acceso in accesos)
                {
                    if (acceso.GetCount() == 0) // Si es una patente
                    {
                        if (!patentes.Any(p => p.Id == acceso.Id))
                        {
                            patentes.Add(acceso as Patente);
                        }
                    }
                    else // Si es una familia
                    {
                        var familia = acceso as Familia;
                        ObtenerPatentesRecursivo(familia.GetAccesos(), patentes);
                    }
                }
            }

            // Método para obtener todas las familias del empleado
            public List<Familia> GetFamilias()
            {
                List<Familia> familias = new List<Familia>();
                ObtenerFamiliasRecursivo(Accesos, familias);
                return familias;
            }

            private void ObtenerFamiliasRecursivo(List<Acceso> accesos, List<Familia> familias)
            {
                foreach (var acceso in accesos)
                {
                    if (acceso.GetCount() > 0) // Si es una familia
                    {
                        var familia = acceso as Familia;
                        if (!familias.Any(f => f.Id == familia.Id))
                        {
                            familias.Add(familia);
                        }
                        ObtenerFamiliasRecursivo(familia.GetAccesos(), familias);
                    }
                }
            }
        }
    }
}
