﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Diagnostics;
using System.IO;
using System.Configuration;
using Dominio;

namespace Services
{

    internal static class LoggerDao
    {
        // Configuración de rutas para los archivos de logs
        private static string PathLogError { get; set; } = ConfigurationManager.AppSettings["PathLogError"];
        private static string PathLogInfo { get; set; } = ConfigurationManager.AppSettings["PathLogInfo"];

        // Método para escribir un log, ya sea de error o de información
        public static void WriteLog(Log log, Exception ex = null)
        {
            switch (log.TraceLevel)
            {
                case TraceLevel.Error:
                    string errorMessage = FormatMessage(log);
                    if (ex != null) errorMessage += $"\nStack Trace: {ex.StackTrace}";  // Añadir traza de error si hay excepción
                    WriteToFile(PathLogError, errorMessage);
                    break;

                case TraceLevel.Info:
                case TraceLevel.Warning:
                case TraceLevel.Verbose:
                    string infoMessage = FormatMessage(log);
                    WriteToFile(PathLogInfo, infoMessage);
                    break;
            }
        }

        // Formatear el mensaje del log con la fecha, nivel de traza y el mensaje
        private static string FormatMessage(Log log)
        {
            return $"{log.Date:dd/MM/yyyy HH:mm:ss} [{log.TraceLevel}] Usuario: {log.UserId} - {log.Message}";
        }

        // Escribir el mensaje formateado en el archivo correspondiente
        private static void WriteToFile(string path, string message)
        {
            // Generar un nombre de archivo que incluye la fecha
            string fullPath = Path.Combine(path, DateTime.Now.ToString("yyyy-MM-dd") + ".log");

            // Asegurarnos de que el directorio exista
            if (!Directory.Exists(path))
            {
                Directory.CreateDirectory(path);
            }

            // Escribir el mensaje en el archivo
            using (StreamWriter writer = new StreamWriter(fullPath, true))
            {
                writer.WriteLine(message);
            }
        }
    }
}
