﻿using DAO.Repositorio;
using DAO.UnitofWork;

using Dominio;
using Services.Logic;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Diagnostics.Contracts;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL
{
    public class EmpleadoBLL
    {
        private readonly IUnitOfWork _unitOfWork;

        public EmpleadoBLL(IUnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }

        public bool VerificarCredenciales(string nombreUsuario, string contraseña)
        {
            var empleado = _unitOfWork.EmpleadoRepository.ObtenerPorCredenciales(nombreUsuario, contraseña);
            return empleado != null;
        }

        public Empleado ObtenerDetallesEmpleado(string nombreUsuario, string contraseña)
        {
            // Utiliza el método ObtenerPorCredenciales del repositorio a través del UnitOfWork
            return _unitOfWork.EmpleadoRepository.ObtenerPorCredenciales(nombreUsuario, contraseña);
        }

        public void AltaEmpleado(Guid id,string nombre, string apellido, string email, string nombreUsuario, string contraseña, int idRol)
        {
            try
            {
                // _unitOfWork.BeginTransaction(); // Inicia la transacción

                var nuevoEmpleado = new Empleado
                {
                    EmpleadoGuid = id,
                    Nombre = nombre,
                    Apellido = apellido,
                    Email = email,
                    IdRol = idRol,
                    NombreUsuario = nombreUsuario,
                    Contraseña = contraseña
                };


                _unitOfWork.EmpleadoRepository.InsertarEmpleado(nuevoEmpleado);

                _unitOfWork.Commit(); // Confirmar la transacción si todo fue bien

                // Registrar log de éxito
                var log = new Log
                {
                    TraceLevel = TraceLevel.Info,
                    Message = $"Nuevo empleado {nombreUsuario} creado correctamente.",
                    UserId = id.ToString()
                };
                LoggerLogic.WriteLog(log);

            }
            catch(Exception ex)
            {
                // Registrar log de error
                var log = new Log
                {
                    TraceLevel = TraceLevel.Error,
                    Message = $"Error al crear empleado {nombreUsuario}.",
                    UserId = id.ToString()
                };
                LoggerLogic.WriteLog(log, ex);

                _unitOfWork.Rollback(); // Deshacer la transacción en caso de error
                throw;
            }
        }

        public List<Empleado> ObtenerTodosLosEmpleados()
        {
            return _unitOfWork.EmpleadoRepository.ObtenerTodosLosEmpleados();
        }

        public List<Empleado> BuscarEmpleados(string criterio)
        {
            return _unitOfWork.EmpleadoRepository.BuscarEmpleados(criterio);
        }

        public void ModificarEmpleado(Empleado empleado)
        {
            try
            {
                _unitOfWork.BeginTransaction();
                _unitOfWork.EmpleadoRepository.ModificarEmpleado(empleado);
                _unitOfWork.Commit(); // Confirmar la transacción si todo fue bien

                // Registrar log de éxito
                var log = new Log
                {
                    TraceLevel = TraceLevel.Info,
                    Message = $"Empleado: {empleado.Nombre} Modificado correctamente.",
                    UserId = empleado.EmpleadoGuid.ToString()
                };
                LoggerLogic.WriteLog(log);
            }
            catch(Exception ex)
            {
                // Registrar log de error
                var log = new Log
                {
                    TraceLevel = TraceLevel.Info,
                    Message = $"El Empleado: {empleado.Nombre} NO se pudo modificar correctamente.",
                    UserId = empleado.EmpleadoGuid.ToString()
                };
                LoggerLogic.WriteLog(log, ex);


                _unitOfWork.Rollback(); // Deshacer la transacción en caso de error
                throw;
            }
        }

        public void EliminarEmpleado(int idEmpleado)
        {
            try
            {
                _unitOfWork.BeginTransaction();

                // Obtener el EmpleadoGuid a través del idEmpleado
                var empleado = _unitOfWork.EmpleadoRepository.ObtenerEmpleadoPorId(idEmpleado);
                if (empleado == null)
                    throw new Exception("Empleado no encontrado.");

                _unitOfWork.EmpleadoRepository.EliminarEmpleado(empleado.EmpleadoGuid);
                _unitOfWork.Commit(); // Confirmar la transacción si todo fue bien

                // Registrar log de éxito
                var log = new Log
                {
                    TraceLevel = TraceLevel.Info,
                    Message = $"Empleado: {empleado.Nombre} Eliminado correctamente.",
                    UserId = empleado.EmpleadoGuid.ToString()
                };
                LoggerLogic.WriteLog(log);
            }
            catch(Exception ex)
            {
                // Registrar log de error
                var log = new Log
                {
                    TraceLevel = TraceLevel.Info,
                    Message = $"El Empleado: {idEmpleado} NO se pudo eliminar correctamente.",
                    UserId = idEmpleado.ToString()
                };
                LoggerLogic.WriteLog(log, ex);

                _unitOfWork.Rollback(); // Deshacer la transacción en caso de error
                throw;
            }
        }

        public Empleado ObtenerEmpleadoPorId(int idEmpleado)
        {
            return _unitOfWork.EmpleadoRepository.ObtenerEmpleadoPorId(idEmpleado);
        }


    }
}
