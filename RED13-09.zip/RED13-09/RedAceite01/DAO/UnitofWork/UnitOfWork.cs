﻿ using DAO.Repositorio;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAO.UnitofWork
{
    public class UnitOfWork : IUnitOfWork
    {
        private readonly SqlConnection _connection;
        private SqlTransaction _transaction; // No inicializar la transacción aquí
        public IEmpleadoRepository EmpleadoRepository { get; private set; }

        public UnitOfWork(string connectionString)
        {
            _connection = new SqlConnection(connectionString);
            _connection.Open();

            // Inicializar los repositorios aquí, pero no la transacción
            EmpleadoRepository = new EmpleadoRepository(_connection, _transaction);
        }

        // Implementar BeginTransaction para iniciar una transacción
        public void BeginTransaction()
        {
            if (_transaction == null)
            {
                _transaction = _connection.BeginTransaction();
            }

            // Pasar la transacción a los repositorios si es necesario
            EmpleadoRepository.UseTransaction(_transaction);
        }

        public void Commit()
        {
            try
            {
                _transaction?.Commit(); // Solo hacer commit si la transacción no es nula
            }
            catch
            {
                _transaction?.Rollback(); // Si hay un error, hacer rollback
                throw;
            }
            finally
            {
                DisposeTransaction(); // Liberar la transacción, pero no la conexión aún
            }
        }

        public void Rollback()
        {
            try
            {
                _transaction?.Rollback(); // Hacer rollback si la transacción no es nula
            }
            finally
            {
                DisposeTransaction(); // Liberar la transacción, pero no la conexión aún
            }
        }

        private void DisposeTransaction()
        {
            if (_transaction != null)
            {
                _transaction.Dispose(); // Liberar los recursos de la transacción
                _transaction = null; // Asegurarse de que no se reutilice
            }
        }

        public void Dispose()
        {
            DisposeTransaction(); // Asegúrate de que la transacción esté cerrada
            _connection.Close(); // Cerrar la conexión
            _connection.Dispose(); // Liberar la conexión
        }

    }
}
