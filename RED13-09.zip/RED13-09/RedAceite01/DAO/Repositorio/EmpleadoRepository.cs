﻿using Dominio;
using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAO.Repositorio
{
    public class EmpleadoRepository : IEmpleadoRepository
    {
        private readonly SqlConnection _connection;
        private SqlTransaction _transaction;
        public EmpleadoRepository(SqlConnection connection, SqlTransaction transaction)
        {
            _connection = connection;
            _transaction = transaction;
        }
        // Implementar el método para actualizar la transacción
        public void UseTransaction(SqlTransaction transaction)
        {
            _transaction = transaction;
        }
        public Empleado ObtenerPorCredenciales(string nombreUsuario, string contraseña)
        {
            Empleado empleado = null;

            using (SqlCommand command = new SqlCommand())
            {
                command.Connection = _connection;
                command.Transaction = _transaction;
                command.CommandText = @"SELECT u.*, r.idRol, ur.NombreRol
                                        FROM [User] u
                                        JOIN RolUser r ON u.EmpleadoGuid = r.EmpleadoGuid
                                        JOIN UserRoles ur ON r.IdRol = ur.idRol
                                        WHERE u.nombreUsuario = @nombreUsuario AND u.contraseña = @contraseña;";
                command.Parameters.AddWithValue("@nombreUsuario", nombreUsuario);
                command.Parameters.AddWithValue("@contraseña", contraseña);

                using (SqlDataReader reader = command.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        empleado = new Empleado
                        {
                            EmpleadoGuid = (Guid)reader["EmpleadoGuid"],
                            IdEmpleado = (int)reader["idEmpleado"],
                            Nombre = (string)reader["Nombre"],
                            Apellido = (string)reader["Apellido"],
                            Email = (string)reader["Email"],
                            IdRol = (int)reader["idRol"],
                            NombreUsuario = reader["nombreUsuario"].ToString(),
                            Contraseña = reader["contraseña"].ToString(),
                            NombreRol = reader["NombreRol"].ToString()
                            
                        };
                    }
                }
            }
            return empleado;
        }

        public void InsertarEmpleado(Empleado empleado)
        {
            using (SqlCommand command = new SqlCommand())
            {
                command.Connection = _connection;  // Usar la conexión pasada
                command.Transaction = _transaction;
                command.CommandText = @"INSERT INTO [User] (EmpleadoGuid, Nombre, Apellido, Email, IdRol, nombreUsuario, contraseña) 
                                        VALUES(@EmpleadoGuid, @Nombre, @Apellido, @Email, @IdRol, @nombreUsuario, @contraseña );

                                        INSERT INTO [RolUser] (EmpleadoGuid, IdRol)
                                        VALUES (@EmpleadoGuid, @IdRol);";
                
                command.Parameters.AddWithValue("@EmpleadoGuid", empleado.EmpleadoGuid);
                command.Parameters.AddWithValue("@Nombre", empleado.Nombre);
                command.Parameters.AddWithValue("@Apellido", empleado.Apellido);
                command.Parameters.AddWithValue("@Email", empleado.Email);
                command.Parameters.AddWithValue("@IdRol", empleado.IdRol);
                command.Parameters.AddWithValue("@nombreUsuario", empleado.NombreUsuario);
                command.Parameters.AddWithValue("@contraseña", empleado.Contraseña);
                command.ExecuteNonQuery();
                command.Connection.Close();
            }

        }
    }
}
