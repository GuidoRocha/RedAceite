﻿using BLL;
using BLL.Factory;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RedAceite01
{
    public partial class LoginForm : Form
    {
        public LoginForm()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void BtnLogIn_Click(object sender, EventArgs e)
        {
            string nombreUsuario = txtNombreUsuario.Text;
            string contraseña = TxtContraseña.Text;

            // Utilizar la fábrica en la capa BLL para crear EmpleadoBLL
            IEmpleadoBLLFactory factory = new EmpleadoBLLFactory();
            EmpleadoBLL empleadoBLL = factory.CrearEmpleadoBLL();

            bool esValido = empleadoBLL.VerificarCredenciales(nombreUsuario, contraseña);

            if (esValido)
            {
                var mainForm = new MainForm(); // Suponiendo que tienes un formulario principal
                mainForm.Show();
            }
            else
            {
                MessageBox.Show("Nombre de usuario o contraseña incorrectos");
            }
        }
    }
}
