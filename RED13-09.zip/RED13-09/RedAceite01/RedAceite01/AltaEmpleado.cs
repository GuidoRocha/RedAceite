﻿using BLL;
using BLL.Factory;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RedAceite01
{
    public partial class AltaEmpleado : Form
    {
        private EmpleadoBLL _empleadoBLL;

        public AltaEmpleado()
        {
            InitializeComponent();
            // Crear una instancia de EmpleadoBLLFactory
            var factory = new EmpleadoBLLFactory();
            _empleadoBLL = factory.CrearEmpleadoBLL();// Llamada a través de la instancia
        }

        private void btnAltaEmpleado_Click(object sender, EventArgs e)
        {
            try
            {
                // Pasar los datos directamente al método AltaEmpleado de la BLL
                _empleadoBLL.AltaEmpleado(
                    Guid.NewGuid(),
                    txtNombre.Text,
                    txtApellido.Text,
                    txtEmail.Text,
                    txtNombreUsuario.Text,
                    txtContraseña.Text,
                    int.Parse(txtRol.Text)
                );

                MessageBox.Show("Empleado dado de alta con éxito");
                LimpiarCampos();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al dar de alta el empleado: {ex.Message}");
            }
        }

        private void LimpiarCampos()
        {
            txtNombre.Text = string.Empty;
            txtApellido.Text = string.Empty;
            txtEmail.Text = string.Empty;
            txtNombreUsuario.Text = string.Empty;
            txtContraseña.Text = string.Empty;
            txtRol.Text = string.Empty;
        }
    }
}
