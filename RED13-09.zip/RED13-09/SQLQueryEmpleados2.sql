INSERT INTO [User]  (EmpleadoGuid, Nombre, Apellido, Email, IdRol, nombreUsuario, contrase�a)
VALUES 
(NEWID(), 'Juan', 'P�rez', 'juan.perez@example.com', 1, 'JuanP�rez', '123'),
(NEWID(), 'Ana', 'Garc�a', 'ana.garcia@example.com', 2, 'AnaGarc�a', '123'),
(NEWID(), 'Carlos', 'L�pez', 'carlos.lopez@example.com', 1, 'CarlosL�pez', '123'),
(NEWID(), 'Mar�a', 'G�mez', 'maria.gomez@example.com', 2, 'Mar�aG�mez', '123'),
(NEWID(), 'Luis', 'Mart�nez', 'luis.martinez@example.com', 1, 'LuisMart�nez', '123');

INSERT INTO [User] (EmpleadoGuid, Nombre, Apellido, Email, IdRol, nombreUsuario, contrase�a)
VALUES 
(NEWID(), 'Juannnn', 'P�reznnn', 'juan.perez@example.com', 1, 'JuanP�reznnn', '123'),


INSERT INTO UserRoles (NombreRol)
VALUES
('Admin'),
('Regular')

INSERT INTO [RolUser] (EmpleadoGuid, IdRol)
VALUES
('515ebeb4-fe9d-4912-8cb5-238276917e26', 1),
('9b160c33-7d82-4de3-8041-41a8af05db66', 1),
('c5d8d220-9100-461d-a494-5320bc8ee3be', 2),
('28cdce50-3372-4132-b169-6b290b33e32b', 2),
('92ef436b-cd5f-4879-afef-6b84c653fd49', 1);


SELECT u.*, r.idRol, ur.NombreRol
FROM [User] u
JOIN RolUser r ON u.EmpleadoGuid = r.EmpleadoGuid
JOIN UserRoles ur ON r.IdRol = ur.idRol
WHERE u.nombreUsuario = 'LuisMart�nez' AND u.contrase�a = 123;

SELECT u.*
FROM [User] u