﻿using BLL;
using BLL.Factory;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using RedAceite01;
using Dominio;
using System.Diagnostics;
using Services;
using Services.Logic;

namespace RedAceite01
{
    public partial class LoginForm : Form
    {
        public LoginForm()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        
        private void BtnLogIn_Click(object sender, EventArgs e)
        {

            string nombreUsuario = txtNombreUsuario.Text;
            string contraseña = TxtContraseña.Text;

            IEmpleadoBLLFactory factory = new EmpleadoBLLFactory();
            EmpleadoBLL empleadoBLL = factory.CrearEmpleadoBLL();

            try
            {

                var empleado = empleadoBLL.ObtenerDetallesEmpleado(nombreUsuario, contraseña);

                 if (empleado != null)
                 {

                    // Login exitoso: Escribir un log de éxito
                    var log = new Log
                    {
                       TraceLevel = TraceLevel.Info,
                       Message = $"Inicio de sesión exitoso para el usuario {empleado.NombreUsuario}.",
                       UserId = empleado.EmpleadoGuid.ToString()
                    };

                    LoggerLogic.WriteLog(log);

                    // Verificar si el usuario tiene el permiso de "ABM Empleados"
                    if (empleado.Permisos.Contains("ABM Empleados"))
                    {
                       // Mostrar mensaje y continuar a la vista de empleados
                       var vistaEmpleados = new vistaEmpleados(empleado); // Pasar el empleado logueado
                       vistaEmpleados.Show();
                    }
                    else
                    {
                       // Registrar log de acceso restringido
                       var permisoDenegadoLog = new Log
                       {
                          TraceLevel = TraceLevel.Warning, // Nivel de advertencia porque no es un error
                          Message = $"El usuario {empleado.NombreUsuario} intentó acceder a ABM Empleados sin permisos.",
                          UserId = empleado.EmpleadoGuid.ToString()
                       };

                         LoggerLogic.WriteLog(permisoDenegadoLog);

                         MessageBox.Show("No tiene permiso para acceder al ABM de empleados.");
                    }

                     // Ocultar el formulario de login en ambos casos (con o sin permisos)
                     this.Hide();
                 }
                 else
                 {
                     // Nombre de usuario o contraseña incorrectos
                     MessageBox.Show("Nombre de usuario o contraseña incorrectos");

                     // Registrar un log de error
                     var log = new Log
                     {
                        TraceLevel = TraceLevel.Error,
                        Message = "Intento de inicio de sesión fallido.",
                        UserId = "Desconocido"
                     };

                      LoggerLogic.WriteLog(log);
                 }
              }
                  catch (Exception ex)
                {
                    // Error durante el proceso de login
                    MessageBox.Show($"Error al intentar iniciar sesión: {ex.Message}");

                    // Registrar un log de error
                    var log = new Log
                    {
                        TraceLevel = TraceLevel.Error,
                        Message = $"Error durante el inicio de sesión para el usuario {nombreUsuario}.",
                        UserId = "Desconocido"
                    };
                    LoggerLogic.WriteLog(log, ex);
                }
            }
        
    }
}
