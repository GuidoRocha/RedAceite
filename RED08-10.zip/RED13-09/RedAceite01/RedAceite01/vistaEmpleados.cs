﻿using BLL.Factory;
using BLL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Dominio;

namespace RedAceite01
{
    public partial class vistaEmpleados : Form
    {

        private readonly Empleado _empleadoLogueado;
        private EmpleadoBLL _empleadoBLL;
        private List<Empleado> _empleados; // Lista completa de empleados

        public vistaEmpleados(Empleado empleadoLogueado)
        {
            InitializeComponent();

            // Recibimos el empleado logueado
            _empleadoLogueado = empleadoLogueado;

            // Creamos una instancia de EmpleadoBLL utilizando la fábrica
            IEmpleadoBLLFactory factory = new EmpleadoBLLFactory();
            _empleadoBLL = factory.CrearEmpleadoBLL();
        }

        private void VistaEmpeleados_Load(object sender, EventArgs e)
        {
            // Llamamos al método para llenar el DataGridView con los empleados
            LlenarDataGridEmpleados();

            // Limpiar cualquier selección predeterminada
            dataGridView1.ClearSelection();

        }
        private void LlenarDataGridEmpleados()
        {
            try
            {
                var empleados = _empleadoBLL.ObtenerTodosLosEmpleados();
                dataGridView1.DataSource = empleados; // Asigna la lista al DataGridView

                                                      // Oculta las columnas que no quieres mostrar
                dataGridView1.Columns["EmpleadoGuid"].Visible = false;
                dataGridView1.Columns["IdRol"].Visible = false;
                dataGridView1.Columns["Contraseña"].Visible = false;
                dataGridView1.RowHeadersVisible = false;
                dataGridView1.Columns[1].HeaderText = "Codigo Empleado";
                dataGridView1.Columns[5].HeaderText = "Email usuario";
                dataGridView1.Columns[6].HeaderText = "Nombre de Usuario";
                dataGridView1.Columns[8].HeaderText = "Tipo de usuario";
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al cargar los empleados: {ex.Message}");
            }
        }



        // Evento TextChanged para el TextBox de búsqueda

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            FiltrarEmpleados(txtBuscar.Text);

        }
        private void FiltrarEmpleados(string criterio)
        {
            try
            {
                // Limpiar el criterio de búsqueda: eliminar espacios extra
                criterio = criterio.Trim();
                criterio = string.Join(" ", criterio.Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries));

                // Llamar al método de búsqueda en la capa BLL
                var empleadosFiltrados = _empleadoBLL.BuscarEmpleados(criterio);

                // Actualizar el DataGridView con la lista filtrada
                dataGridView1.DataSource = empleadosFiltrados;

                // Ocultar las columnas que no quieres mostrar
                dataGridView1.Columns["EmpleadoGuid"].Visible = false;
                dataGridView1.Columns["IdRol"].Visible = false;
                dataGridView1.Columns["Contraseña"].Visible = false;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al buscar empleados: {ex.Message}");
            }
        }

        private void RefrescarDataGridEmpleados()
        {
            try
            {
                // Llamar al método de la capa BLL para obtener todos los empleados
                var empleados = _empleadoBLL.ObtenerTodosLosEmpleados();

                // Asignar los datos al DataGridView
                dataGridView1.DataSource = empleados;

                // Ocultar las columnas que no deseas mostrar
                dataGridView1.Columns["EmpleadoGuid"].Visible = false;
                dataGridView1.Columns["Contraseña"].Visible = false;
                dataGridView1.Columns["IdRol"].Visible = false;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al cargar los empleados: {ex.Message}");
            }
        }
        

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dataGridView1_CellContentDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            // Verificar que se ha hecho clic en una fila válida
            if (e.RowIndex >= 0)
            {
                // Obtener el empleado seleccionado de la fila
                var empleadoSeleccionado = (Empleado)dataGridView1.Rows[e.RowIndex].DataBoundItem;

                // Abrir el formulario AltaEmpleado en modo edición
                AbrirAltaEmpleado(empleadoSeleccionado);
            }
        }
        private void AbrirAltaEmpleado(Empleado empleado = null)
        {
            var altaEmpleadoForm = new AltaEmpleado(empleado);

            // Suscribirse al evento OnEmpleadoAlterado para actualizar el DataGridView
            altaEmpleadoForm.OnEmpleadoAlterado += RefrescarDataGridEmpleados;

            altaEmpleadoForm.ShowDialog(); // Mostrar el formulario como un diálogo modal
        }

        private void btnNuevoEmpleado_Click(object sender, EventArgs e)
        {
            AbrirAltaEmpleado(); // Abre el formulario sin pasar un empleado
        }

        private void btnSeleccionar_Click(object sender, EventArgs e)
        {
            // Verificar que se ha seleccionado una fila
            if (dataGridView1.SelectedRows.Count > 0)
            {
                // Obtener el empleado seleccionado de la fila
                var empleadoSeleccionado = (Empleado)dataGridView1.SelectedRows[0].DataBoundItem;

                // Abrir el formulario AltaEmpleado en modo edición
                AbrirAltaEmpleado(empleadoSeleccionado);
            }
            else
            {
                MessageBox.Show("Por favor, selecciona un empleado de la lista.");
            }
        }
    }
}
