﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dominio
{
    public class Empleado
    {
        public Guid EmpleadoGuid { get; set; } // ID único del empleado
        public int IdEmpleado { get; set; }
        public string Nombre { get; set; }
        public string Apellido { get; set; }
        public int IdRol { get; set; } // Quizás querrás cambiar esto a IdFamilia
        public string Email { get; set; }
        public string NombreUsuario { get; set; }
        public string Contraseña { get; set; }

        // Propiedad para representar los permisos del usuario
        public List<string> Permisos { get; set; } // Lista de permisos

        // Propiedad para representar el nombre del rol (familia)
        public string NombreRol { get; set; }
    }
}
