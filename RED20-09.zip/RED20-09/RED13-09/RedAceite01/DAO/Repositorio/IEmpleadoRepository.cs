﻿using Dominio;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAO.Repositorio
{
    public interface IEmpleadoRepository
    {
        Empleado ObtenerPorCredenciales(string nombreUsuario, string contraseña);

        void InsertarEmpleado(Empleado empleado);
        void ModificarEmpleado(Empleado empleado); 
        void EliminarEmpleado(Guid empleadoGuid); 
        Empleado ObtenerEmpleadoPorId(int idEmpleado); 

        void llenarDataEmpleados();


        // Método para actualizar la transacción en el repositorio
        void UseTransaction(SqlTransaction transaction);

        // Añadir el método ObtenerTodosLosEmpleados a la interfaz
        List<Empleado> ObtenerTodosLosEmpleados();

        List<Empleado> BuscarEmpleados(string criterio);
    }
}
