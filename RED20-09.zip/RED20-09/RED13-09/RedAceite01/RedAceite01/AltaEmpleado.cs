﻿using BLL;
using BLL.Factory;
using Dominio;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RedAceite01
{
    public partial class AltaEmpleado : Form
    {
        private EmpleadoBLL _empleadoBLL;
        private Empleado _empleado; // Almacenar el empleado seleccionado para modificación
        // Evento para notificar cambios
        public event Action OnEmpleadoAlterado;

        public AltaEmpleado(Empleado empleado = null)
        {
            InitializeComponent();
            // Crear una instancia de EmpleadoBLLFactory
            var factory = new EmpleadoBLLFactory();
            _empleadoBLL = factory.CrearEmpleadoBLL();// Llamada a través de la instancia

            // Solo cargar datos si se pasa un empleado, es decir, estamos en modo edición
            if (empleado != null)
            {
                _empleado = empleado;
                CargarDatosEmpleado();
                btnAltaEmpleado.Text = "Guardar"; // Cambiar el texto a "Guardar" para edición
            }
            else
            {
                btnAltaEmpleado.Text = "Crear Empleado"; // Cambiar el texto a "Crear Empleado" para alta
                btnEliminar.Visible = false; // Ocultar el botón de eliminar si estamos en modo alta
            }
        }
        // Método para cargar los datos del empleado en los campos de texto
        private void CargarDatosEmpleado()
        {
            txtNombre.Text = _empleado.Nombre;
            txtApellido.Text = _empleado.Apellido;
            txtEmail.Text = _empleado.Email;
            txtNombreUsuario.Text = _empleado.NombreUsuario;
            txtContraseña.Text = _empleado.Contraseña;
            // Seleccionar el valor en el ComboBox según el IdRol
            comboBoxRol.SelectedItem = _empleado.IdRol == 1 ? "Usuario Administrador" : "Usuario Regular";

        }

        private void btnAltaEmpleado_Click(object sender, EventArgs e)
        {
            try
            {
                // Obtener el valor de IdRol según la selección del ComboBox
                int idRol = 0;
                if (comboBoxRol.SelectedItem != null)
                {
                    string rolSeleccionado = comboBoxRol.SelectedItem.ToString();
                    idRol = rolSeleccionado == "Usuario Administrador" ? 1 : 2; // Asignar 1 para "Administrador" y 2 para "Regular"
                }
                else
                {
                    MessageBox.Show("Por favor, seleccione un rol.");
                    return;
                }

                if (_empleado != null)
                {
                   
                    // Modo Modificación
                    var empleado = _empleadoBLL.ObtenerEmpleadoPorId(int.Parse(_empleado.IdEmpleado.ToString()));
                    empleado.Nombre = txtNombre.Text;
                    empleado.Apellido = txtApellido.Text;
                    empleado.Email = txtEmail.Text;
                    empleado.NombreUsuario = txtNombreUsuario.Text;
                    empleado.Contraseña = txtContraseña.Text;
                    empleado.IdRol = idRol;

                    _empleadoBLL.ModificarEmpleado(empleado);
                    MessageBox.Show("Empleado modificado con éxito.");
                }
                else
                {
                    // Modo Alta
                    _empleadoBLL.AltaEmpleado(
                        Guid.NewGuid(),
                        txtNombre.Text,
                        txtApellido.Text,
                        txtEmail.Text,
                        txtNombreUsuario.Text,
                        txtContraseña.Text,
                        idRol
                    );

                    MessageBox.Show("Empleado dado de alta con éxito.");
                }

                LimpiarCampos();
                // Disparar el evento para notificar los cambios y actualizar el DataGridView
                OnEmpleadoAlterado?.Invoke();
                
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al guardar el empleado: {ex.Message}");
            }
        }

        private void LimpiarCampos()
        {
            txtNombre.Text = string.Empty;
            txtApellido.Text = string.Empty;
            txtEmail.Text = string.Empty;
            txtNombreUsuario.Text = string.Empty;
            txtContraseña.Text = string.Empty;
            comboBoxRol.SelectedIndex = -1; // Reiniciar la selección del ComboBox
        }

        private void AltaEmpleado_Load(object sender, EventArgs e)
        {

        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            try
            {
                int idEmpleado = _empleado.IdEmpleado;
                _empleadoBLL.EliminarEmpleado(idEmpleado);
                MessageBox.Show("Empleado eliminado con éxito.");
                LimpiarCampos();
                // Disparar el evento para notificar los cambios y actualizar el DataGridView
                OnEmpleadoAlterado?.Invoke();
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al eliminar el empleado: {ex.Message}");
            }
        }
    }
}
