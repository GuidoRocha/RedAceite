INSERT INTO [User]  (EmpleadoGuid, Nombre, Apellido, Email, IdRol, nombreUsuario, contrase�a)
VALUES 
(NEWID(), 'Juan', 'P�rez', 'juan.perez@example.com', 1, 'JuanP�rez', '123'),
(NEWID(), 'Ana', 'Garc�a', 'ana.garcia@example.com', 2, 'AnaGarc�a', '123'),
(NEWID(), 'Carlos', 'L�pez', 'carlos.lopez@example.com', 1, 'CarlosL�pez', '123'),
(NEWID(), 'Mar�a', 'G�mez', 'maria.gomez@example.com', 2, 'Mar�aG�mez', '123'),
(NEWID(), 'Luis', 'Mart�nez', 'luis.martinez@example.com', 1, 'LuisMart�nez', '123');

INSERT INTO [User] (EmpleadoGuid, Nombre, Apellido, Email, IdRol, nombreUsuario, contrase�a)
VALUES 
(NEWID(), 'Juannnn', 'P�reznnn', 'juan.perez@example.com', 1, 'JuanP�reznnn', '123');


INSERT INTO UserRoles (NombreRol)
VALUES
('Admin'),
('Regular')

INSERT INTO [RolUser] (EmpleadoGuid, IdRol)
VALUES
('75059C53-C21C-42FE-B267-0C2A856D1ADB', 1),
('C1510C94-0598-495D-BECD-1153ED021983', 1),
('B268F19B-BFD2-4B0F-BBE0-1559761793C3', 2),
('329B67C1-BE4A-4F37-B845-3D852EEBCD31', 2),
('21A3532C-B83F-4035-BD5C-DAD8E1CC572D', 1);


SELECT u.*, r.idRol, ur.NombreRol
FROM [User] u
JOIN RolUser r ON u.EmpleadoGuid = r.EmpleadoGuid
JOIN UserRoles ur ON r.IdRol = ur.idRol
WHERE u.nombreUsuario = 'v' AND u.contrase�a = 'v';

SELECT u.*
FROM [User] u

Select * from RolUser